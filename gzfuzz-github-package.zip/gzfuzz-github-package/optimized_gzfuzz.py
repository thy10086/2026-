#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
优化版GzFuzz模块 - 多版本支持版
支持测试不同版本的Gazebo以发现更多崩溃
"""

import os
import sys
import time
import json
import random
import subprocess
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'modules'))

from sdf_generator import SDFModelGenerator
from gazebo_runner import GazeboRunner, MockGazeboRunner, GazeboVersionManager, GAZEBO_VERSIONS, KNOWN_VULNERABLE_VERSIONS
from crash_detector_real import RealCrashDetector, MockCrashDetector
from rl_policy_nn import ActorCriticNN as ActorCriticPolicy


class GazeboEnvironment:
    """Gazebo环境控制类"""
    
    def __init__(self):
        self.process = None
        self.running = False
        self.model_count = 0
    
    def start_gazebo(self, world_file=None):
        try:
            cmd = ['wsl', '-d', 'Ubuntu-20.04', '-e', 'bash', '-c', 
                   'source /opt/ros/noetic/setup.bash 2>/dev/null; gzserver']
            
            if world_file:
                cmd[-1] += f' {world_file}'
            
            self.process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            
            time.sleep(3)
            
            if self.process.poll() is None:
                self.running = True
                return True
            else:
                return False
                
        except Exception as e:
            print(f"启动Gazebo失败: {e}")
            return False
    
    def stop_gazebo(self):
        try:
            if self.process:
                subprocess.run(
                    ['wsl', '-d', 'Ubuntu-20.04', '-e', 'bash', '-c', 
                     'pkill -9 gzserver; pkill -9 gzclient'],
                    capture_output=True
                )
                self.process = None
                self.running = False
                self.model_count = 0
        except Exception as e:
            print(f"停止Gazebo失败: {e}")
    
    def clear_all_models(self):
        self.model_count = 0
    
    def spawn_model(self, model_name, sdf_content):
        self.model_count += 1
        return True
    
    def is_running(self):
        return self.running


class OptimizedGzFuzz:
    """优化版GzFuzz模糊测试器 - 多版本支持"""
    
    ACTIONS = [
        'add_model', 'remove_model', 'add_plugin', 'modify_pose', 
        'execute_service', 'execute_topic', 'reset_world',
        'add_negative_size', 'add_infinite_velocity', 'add_invalid_clip',
        'add_null_pointer', 'add_buffer_overflow', 'add_division_zero'
    ]
    
    def __init__(self, output_dir='gzfuzz_results', use_gazebo=False, seed=None,
                 wait_time=30, crash_check_interval=1, gazebo_versions=None,
                 rotate_versions=True):
        self.output_dir = output_dir
        self.use_gazebo = use_gazebo
        self.seed = seed
        self.wait_time = wait_time
        self.crash_check_interval = crash_check_interval
        self.rotate_versions = rotate_versions
        self.current_version_index = 0
        
        self.on_test_complete = None
        self.on_crash_found = None
        self.on_log = None
        self._stop_requested = False
        
        if seed is not None:
            random.seed(seed)
        
        self.sdf_generator = SDFModelGenerator()
        
        if use_gazebo:
            self.gazebo_runner = GazeboRunner("gazebo", verbose=False, headless=True)
            self.crash_detector = RealCrashDetector()
            self.version_manager = GazeboVersionManager()
            
            if gazebo_versions:
                self.target_versions = gazebo_versions
            else:
                self.target_versions = self._get_available_versions()
            
            if self.target_versions:
                print(f"目标Gazebo版本: {self.target_versions}")
        else:
            self.gazebo_runner = MockGazeboRunner(crash_probability=0.3, verbose=False)
            self.crash_detector = MockCrashDetector()
            self.target_versions = ['mock']
        
        self.policy = ActorCriticPolicy(
            state_size=20,
            action_size=13,
            learning_rate=0.001,
            discount_factor=0.99,
            epsilon_start=1.0,
            epsilon_end=0.01,
            epsilon_decay=0.995,
            use_prioritized_replay=True,
            use_adaptive_epsilon=True
        )
        
        self.stats = {
            'total_tests': 0,
            'crashes_found': 0,
            'new_crashes_found': 0,
            'start_time': None,
            'elapsed_time': 0,
            'crash_types': {},
            'action_distribution': [0] * 13,
            'version_crashes': {},
            'versions_tested': []
        }
        
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
    
    def log(self, message):
        if self.on_log:
            self.on_log(message)
        else:
            print(message)
    
    def _get_available_versions(self):
        """获取可用的Gazebo版本"""
        installed = self.version_manager.get_installed_versions()
        if installed:
            return [v['key'] for v in installed]
        
        all_versions = []
        for family in GAZEBO_VERSIONS.values():
            all_versions.extend(family.keys())
        
        return all_versions
    
    def _rotate_version(self):
        """轮换到下一个版本"""
        if not self.target_versions or len(self.target_versions) <= 1:
            return
        
        self.current_version_index = (self.current_version_index + 1) % len(self.target_versions)
        new_version = self.target_versions[self.current_version_index]
        self.gazebo_runner.set_version(new_version)
        self.log(f"  切换到Gazebo版本: {new_version}")
    
    def get_state(self):
        state = [
            self.stats['crashes_found'] / max(self.stats['total_tests'], 1),
            self.policy.epsilon,
            random.random(), random.random(), random.random(),
            random.random(), random.random(), random.random(),
            random.random(), random.random(),
            random.random(), random.random(), random.random(),
            random.random(), random.random(), random.random(),
            random.random(), random.random(), random.random(),
            random.random()
        ]
        return state
    
    def run_single_test(self, test_id):
        state = self.get_state()
        action, _ = self.policy.select_action(state, training=True)
        action_name = self.ACTIONS[action]
        
        crash_type = None if action < 7 else ['negative_size', 'infinite_velocity', 'invalid_clip', 'null_pointer', 'buffer_overflow', 'division_zero'][action - 7]
        world_name = f'world_{test_id}'
        sdf_content = self.sdf_generator.generate_sdf_string(
            world_name, 
            num_models=3, 
            add_crash_trigger=(crash_type is not None)
        )
        
        sdf_file = os.path.join(self.output_dir, f'test_{test_id}.sdf')
        with open(sdf_file, 'w', encoding='utf-8') as f:
            f.write(sdf_content)
        
        current_version = self.target_versions[self.current_version_index] if self.target_versions else None
        
        pid = self.gazebo_runner.start_gazebo(sdf_file)
        
        if pid is None:
            return None
        
        crashed = False
        crash_info = None
        
        if self.use_gazebo:
            total_wait = 0
            while total_wait < self.wait_time and not self._stop_requested:
                time.sleep(self.crash_check_interval)
                total_wait += self.crash_check_interval
                
                crashed, crash_info = self.gazebo_runner.check_crash()
                
                if crashed:
                    break
                
                if not self.gazebo_runner.is_running():
                    break
        else:
            time.sleep(0.1)
            crashed, crash_info = self.gazebo_runner.check_crash()
        
        novelty = self.policy.get_novelty_bonus(state)
        diversity = random.random()
        
        reward = self.policy.calculate_reward(crashed, crash_info, diversity, novelty, action)
        
        next_state = self.get_state()
        self.policy.update(state, action, reward, next_state, crashed)
        
        self.gazebo_runner.stop_gazebo()
        
        self.stats['total_tests'] += 1
        self.stats['action_distribution'][action] += 1
        
        if current_version and current_version not in self.stats['versions_tested']:
            self.stats['versions_tested'].append(current_version)
        
        if crashed:
            self.stats['crashes_found'] += 1
            if crash_info.get('is_new', False):
                self.stats['new_crashes_found'] += 1
            
            crash_type = crash_info['type']
            if crash_type not in self.stats['crash_types']:
                self.stats['crash_types'][crash_type] = 0
            self.stats['crash_types'][crash_type] += 1
            
            if current_version:
                if current_version not in self.stats['version_crashes']:
                    self.stats['version_crashes'][current_version] = []
                self.stats['version_crashes'][current_version].append({
                    'test_id': test_id,
                    'crash_type': crash_type,
                    'action': action_name
                })
            
            self.log(f"    [崩溃] 测试#{test_id} (v{current_version}): {crash_type}")
        
        result = {
            'test_id': test_id,
            'action': action,
            'action_name': action_name,
            'crashed': crashed,
            'crash_info': crash_info,
            'reward': reward,
            'diversity': diversity,
            'epsilon': self.policy.epsilon,
            'sdf_file': sdf_file,
            'gazebo_version': current_version
        }
        
        return result
    
    def run_tests(self, num_tests=100, callback=None):
        self.stats['start_time'] = time.time()
        self.on_test_complete = callback
        self._stop_requested = False
        
        self.log(f"开始模糊测试: {num_tests} 次测试")
        self.log(f"运行模式: {'真实Gazebo' if self.use_gazebo else '模拟演示'}")
        
        if self.use_gazebo:
            self.log(f"每次测试等待时间: {self.wait_time}秒")
            self.log(f"崩溃检查间隔: {self.crash_check_interval}秒")
            self.log(f"目标版本: {self.target_versions}")
            self.log(f"版本轮换: {'启用' if self.rotate_versions else '禁用'}")
        
        results = []
        tests_per_version = num_tests // len(self.target_versions) if self.target_versions else num_tests
        tests_in_current_version = 0
        
        for i in range(num_tests):
            if self._stop_requested:
                self.log(f"测试被用户中断")
                break
            
            if self.rotate_versions and self.use_gazebo and tests_in_current_version >= tests_per_version:
                self._rotate_version()
                tests_in_current_version = 0
            
            result = self.run_single_test(i + 1)
            tests_in_current_version += 1
            
            if result:
                results.append(result)
                
                if self.on_test_complete:
                    self.on_test_complete(result)
                
                if result['crashed'] and self.on_crash_found:
                    self.on_crash_found(result)
            
            if (i + 1) % 10 == 0:
                self.policy.replay(batch_size=32)
                self.log(f"  进度: {i+1}/{num_tests}, 崩溃: {self.stats['crashes_found']}")
        
        elapsed = time.time() - self.stats['start_time']
        self.stats['elapsed_time'] = elapsed
        
        self.log(f"\n测试完成!")
        self.log(f"总测试数: {self.stats['total_tests']}")
        self.log(f"发现崩溃: {self.stats['crashes_found']}")
        self.log(f"新崩溃: {self.stats['new_crashes_found']}")
        self.log(f"崩溃率: {self.stats['crashes_found']/max(self.stats['total_tests'],1)*100:.1f}%")
        self.log(f"运行时间: {elapsed:.2f}秒")
        
        if self.stats['crash_types']:
            self.log(f"\n崩溃类型分布:")
            for ct, count in self.stats['crash_types'].items():
                self.log(f"  - {ct}: {count}")
        
        if self.stats['version_crashes']:
            self.log(f"\n各版本崩溃统计:")
            for version, crashes in self.stats['version_crashes'].items():
                self.log(f"  - {version}: {len(crashes)} 个崩溃")
        
        return results
    
    def stop(self):
        self._stop_requested = True
        self.gazebo_runner.stop_gazebo()
    
    def get_stats(self):
        return self.stats.copy()
    
    def save_results(self):
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        result_file = os.path.join(self.output_dir, f'results_{timestamp}.json')
        
        with open(result_file, 'w', encoding='utf-8') as f:
            json.dump(self.stats, f, indent=2, ensure_ascii=False)
        
        self.log(f"结果已保存到: {result_file}")
        
        return result_file


GzFuzz = OptimizedGzFuzz
