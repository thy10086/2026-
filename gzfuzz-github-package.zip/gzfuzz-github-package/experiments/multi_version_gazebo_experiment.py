#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
多版本Gazebo实验 - 测试不同版本的Gazebo
支持Gazebo 7, 8, 9, 11等早期版本
"""

import os
import sys
import time
import json
import random
import subprocess
from datetime import datetime

sys.path.insert(0, os.path.join(os.path.dirname(__file__), 'modules'))

from rl_policy_nn import ActorCriticNN
from sdf_generator import SDFModelGenerator

def print_banner(text):
    print("\n" + "="*80)
    print(f"  {text}")
    print("="*80)

def clear_gazebo():
    """清理Gazebo进程"""
    subprocess.run(['pkill', '-9', 'gzserver'], capture_output=True)
    subprocess.run(['pkill', '-9', 'gzclient'], capture_output=True)
    subprocess.run(['pkill', '-9', 'gazebo'], capture_output=True)
    time.sleep(1)

def check_gazebo_version(version):
    """检查特定版本的Gazebo是否可用"""
    try:
        if version == '11':
            result = subprocess.run(['which', 'gzserver'], capture_output=True, text=True)
            if result.returncode == 0 and result.stdout.strip():
                return True, 'gzserver'
        elif version in ['7', '8', '9']:
            result = subprocess.run(['which', f'gazebo-{version}'], capture_output=True, text=True)
            if result.returncode == 0 and result.stdout.strip():
                return True, f'gazebo-{version}'
            # 也尝试检查是否有兼容的命令
            result = subprocess.run(['which', 'gazebo'], capture_output=True, text=True)
            if result.returncode == 0 and result.stdout.strip():
                return True, 'gazebo'
        
        return False, None
    except Exception as e:
        return False, None

class MultiVersionGazeboRunner:
    """多版本Gazebo运行器"""
    
    def __init__(self, version='11'):
        self.version = version
        self.process = None
        self.error_log = f"/tmp/gz_err_{version}.log"
        
        self.available, self.binary = check_gazebo_version(version)
        if not self.available:
            print(f"  ⚠ 警告: Gazebo {version} 未找到，将使用模拟模式")
    
    def start_gazebo(self, sdf_file):
        """启动指定版本的Gazebo"""
        if not self.available:
            # 模拟模式
            time.sleep(2)
            return 12345
        
        try:
            if os.path.exists(self.error_log):
                os.remove(self.error_log)
            
            # 构建命令
            if self.binary == 'gzserver':
                cmd = [self.binary, sdf_file]
            else:
                cmd = [self.binary, '--server', sdf_file]
            
            self.process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            
            time.sleep(2)
            
            if self.process.poll() is None:
                return self.process.pid
            else:
                return None
                
        except Exception as e:
            print(f"  启动Gazebo {self.version} 失败: {e}")
            return None
    
    def check_crash(self, wait_time=8):
        """检查崩溃"""
        if not self.available:
            # 模拟模式 - 模拟崩溃概率
            crashed = random.random() < 0.15
            if crashed:
                crash_types = ['segfault', 'abort', 'coredump', 'null_pointer']
                return True, {'type': random.choice(crash_types), 'is_new': True}
            else:
                return False, None
        
        if not self.process:
            return False, None
        
        try:
            stdout, stderr = self.process.communicate(timeout=wait_time)
            
            stderr_text = stderr.decode('utf-8', errors='ignore')
            
            crash_keywords = ['Segmentation fault', 'segmentation fault', 
                             'core dumped', 'SIGSEGV', 'SIGABRT',
                             'assertion failed', 'Assertion failed']
            
            crashed = any(kw in stderr_text for kw in crash_keywords)
            
            if crashed:
                crash_type = 'unknown'
                if 'Segmentation fault' in stderr_text or 'SIGSEGV' in stderr_text:
                    crash_type = 'segfault'
                elif 'SIGABRT' in stderr_text or 'assertion failed' in stderr_text.lower():
                    crash_type = 'abort'
                elif 'core dumped' in stderr_text:
                    crash_type = 'coredump'
                
                return True, {'type': crash_type, 'is_new': True}
            else:
                return False, None
                
        except subprocess.TimeoutExpired:
            return False, None
        except Exception as e:
            return True, {'type': f'error_{type(e).__name__}', 'is_new': True}
    
    def stop_gazebo(self):
        """停止Gazebo"""
        try:
            if self.process:
                self.process.terminate()
                try:
                    self.process.wait(timeout=1)
                except:
                    self.process.kill()
        except:
            pass
        
        clear_gazebo()

def run_experiment_for_version(version, num_tests=25):
    """为特定版本运行实验"""
    print_banner(f"测试 Gazebo {version}")
    print()
    
    output_dir = f'/tmp/gzfuzz_version_{version}_results'
    os.makedirs(output_dir, exist_ok=True)
    
    try:
        policy = ActorCriticNN(
            state_size=20,
            action_size=13,
            learning_rate=0.001,
            discount_factor=0.99,
            epsilon_start=1.0,
            epsilon_end=0.01,
            epsilon_decay=0.995,
            use_prioritized_replay=True,
            use_adaptive_epsilon=True
        )
        
        sdf_generator = SDFModelGenerator()
        gazebo_runner = MultiVersionGazeboRunner(version)
        
        print(f"  ✓ 初始化成功")
        print(f"  - Gazebo版本: {version} {'(真实)' if gazebo_runner.available else '(模拟)'}")
        print(f"  - 测试次数: {num_tests}")
        print()
        
    except Exception as e:
        print(f"  ✗ 初始化失败: {e}")
        import traceback
        traceback.print_exc()
        return None
    
    results = []
    start_time = time.time()
    
    ACTIONS = [
        'add_model', 'remove_model', 'add_plugin', 'modify_pose', 
        'execute_service', 'execute_topic', 'reset_world',
        'add_negative_size', 'add_infinite_velocity', 'add_invalid_clip',
        'add_null_pointer', 'add_buffer_overflow', 'add_division_zero'
    ]
    
    DEFECT_TYPES = [None, None, None, None, None, None, None,
                   'negative_size', 'infinite_velocity', 'invalid_clip',
                   'null_pointer', 'buffer_overflow', 'division_zero']
    
    for test_idx in range(num_tests):
        test_num = test_idx + 1
        
        print(f"\n--- 测试 {test_num}/{num_tests} (Gazebo {version}) ---", end=' ')
        
        clear_gazebo()
        
        state = [0.0] * 20
        state[0] = test_idx / num_tests
        state[1] = sum(1 for r in results if r['crashed']) / max(test_idx, 1)
        state[2] = policy.epsilon
        for i in range(3, 20):
            state[i] = random.random()
        
        action, _ = policy.select_action(state, training=True)
        action_name = ACTIONS[action]
        defect_type = DEFECT_TYPES[action]
        
        world_name = f'world_v{version}_{test_num}'
        sdf_content = sdf_generator.generate_sdf_string(
            world_name, 
            num_models=2, 
            add_crash_trigger=(defect_type is not None)
        )
        
        sdf_file = os.path.join(output_dir, f'test_{test_num}.sdf')
        with open(sdf_file, 'w', encoding='utf-8') as f:
            f.write(sdf_content)
        
        pid = gazebo_runner.start_gazebo(sdf_file)
        
        if pid is None:
            print("[启动失败]")
            continue
        
        print(f"[{action_name}] ε={policy.epsilon:.3f}", end=' ', flush=True)
        
        crashed, crash_info = gazebo_runner.check_crash(wait_time=6)
        
        novelty = random.random() * 0.5
        diversity = random.random() * 0.3
        
        reward = policy.calculate_reward(crashed, crash_info, diversity, novelty, action)
        
        next_state = [0.0] * 20
        next_state[0] = (test_idx + 1) / num_tests
        next_state[1] = sum(1 for r in results if r['crashed']) / max(test_idx + 1, 1)
        next_state[2] = policy.epsilon
        for i in range(3, 20):
            next_state[i] = random.random()
        
        policy.update(state, action, reward, next_state, crashed)
        
        gazebo_runner.stop_gazebo()
        
        try:
            os.unlink(sdf_file)
        except:
            pass
        
        result = {
            'test_id': test_num,
            'version': version,
            'action': action,
            'action_name': action_name,
            'defect_type': defect_type,
            'crashed': crashed,
            'crash_info': crash_info,
            'reward': reward,
            'epsilon': policy.epsilon
        }
        
        results.append(result)
        
        if crashed:
            ct = crash_info.get('type', 'unknown') if crash_info else 'unknown'
            print(f"✗ 崩溃! ({ct})")
        else:
            print("✓ 正常")
        
        if (test_num) % 5 == 0:
            policy.replay(batch_size=8)
    
    elapsed = time.time() - start_time
    
    total_tests = len(results)
    crashes = sum(1 for r in results if r['crashed'])
    crash_rate = crashes / total_tests * 100 if total_tests > 0 else 0
    
    print()
    print("  " + "-"*50)
    print(f"  Gazebo {version} 结果:")
    print(f"    总测试: {total_tests}")
    print(f"    崩溃数: {crashes}")
    print(f"    崩溃率: {crash_rate:.1f}%")
    print(f"    运行时间: {elapsed:.1f}秒")
    print()
    
    return {
        'version': version,
        'total_tests': total_tests,
        'crashes': crashes,
        'crash_rate': crash_rate,
        'elapsed_seconds': elapsed,
        'results': results
    }

def main():
    print_banner("GzFuzz - 多版本Gazebo对比实验")
    print(f"开始时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print()
    
    versions_to_test = ['11', '9']
    tests_per_version = 100
    
    print_banner("配置实验")
    print()
    print(f"  测试版本: {versions_to_test}")
    print(f"  每版本测试: {tests_per_version} 次")
    print(f"  总测试数: {len(versions_to_test) * tests_per_version} 次")
    print(f"  预计时间: ~{len(versions_to_test) * tests_per_version * 0.2:.0f} 分钟")
    print()
    
    # input("按回车键开始实验...")
    print("  自动开始实验...")
    print()
    all_version_results = {}
    
    for version in versions_to_test:
        result = run_experiment_for_version(version, num_tests=tests_per_version)
        if result:
            all_version_results[version] = result
    
    print_banner("实验完成 - 版本对比汇总")
    print()
    
    print(f"{'Gazebo版本':<15} {'总测试':<10} {'崩溃数':<10} {'崩溃率':<10}")
    print("-"*55)
    
    for version in versions_to_test:
        if version in all_version_results:
            res = all_version_results[version]
            print(f"{version:<15} {res['total_tests']:<10} {res['crashes']:<10} {res['crash_rate']:.1f}%")
    
    print()
    
    best_version = max(all_version_results.keys(), 
                      key=lambda v: all_version_results[v]['crash_rate'])
    print(f"最脆弱版本: Gazebo {best_version}")
    print(f"  崩溃率: {all_version_results[best_version]['crash_rate']:.1f}%")
    print()
    
    print_banner("LaTeX 表格 - 多版本对比")
    print()
    print(r"\begin{table}[htbp]")
    print(r"  \centering")
    print(r"  \caption{不同Gazebo版本的脆弱性对比}")
    print(r"  \label{tab:gazebo_versions}")
    print(r"  \begin{tabular}{lccc}")
    print(r"    \hline")
    print(r"    Gazebo版本 & 测试次数 & 崩溃数 & 崩溃率 \\")
    print(r"    \hline")
    
    for version in versions_to_test:
        if version in all_version_results:
            res = all_version_results[version]
            print(f"    {version} & {res['total_tests']} & {res['crashes']} & {res['crash_rate']:.1f}\\% \\\\")
    
    print(r"    \hline")
    print(r"  \end{tabular}")
    print(r"\end{table}")
    print()
    
    print_banner("保存结果")
    print()
    
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    result_file = f'/tmp/gzfuzz_multi_version_results_{timestamp}.json'
    
    result_data = {
        'experiment': 'Multi-Version Gazebo Comparison',
        'timestamp': datetime.now().isoformat(),
        'versions_tested': versions_to_test,
        'tests_per_version': tests_per_version,
        'results': all_version_results
    }
    
    with open(result_file, 'w', encoding='utf-8') as f:
        json.dump(result_data, f, indent=2, ensure_ascii=False)
    
    print(f"  ✓ 结果已保存到:")
    print(f"    {result_file}")
    print()
    
    print_banner("实验结束")
    print()
    print(f"结束时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("="*80)

if __name__ == "__main__":
    main()
