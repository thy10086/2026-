#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
崩溃检测器
基于Gazebo错误日志检测崩溃
"""

import re
import os
from datetime import datetime
from collections import defaultdict


class RealCrashDetector:
    """真实的崩溃检测器"""
    
    def __init__(self):
        self.known_crashes = set()
        self.crash_logs = []
        self.crash_counts = defaultdict(int)
        
        self.crash_rewards = {
            'segmentation_fault': 25,
            'assertion_failure': 20,
            'null_pointer': 18,
            'memory_error': 15,
            'stack_overflow': 22,
            'unknown': 10
        }
    
    def check_crash_from_log(self, error_log_path="gz.err"):
        if not os.path.exists(error_log_path):
            return False, None
        
        try:
            with open(error_log_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
        except Exception:
            return False, None
        
        if "Segmentation fault" in content or "SIGSEGV" in content:
            return self._create_crash_info('segmentation_fault', content)
        
        if "Assertion" in content and "failed" in content:
            return self._create_crash_info('assertion_failure', content)
        
        if "nullptr" in content or "NULL pointer" in content:
            return self._create_crash_info('null_pointer', content)
        
        if any(kw in content for kw in ['memory corruption', 'double free', 'invalid free']):
            return self._create_crash_info('memory_error', content)
        
        if "stack overflow" in content.lower():
            return self._create_crash_info('stack_overflow', content)
        
        return False, None
    
    def check_crash_from_exit_code(self, exit_code, error_log_path="gz.err"):
        crash_exit_codes = {
            -11: 'segmentation_fault',
            -6: 'assertion_failure',
            -8: 'memory_error',
            -7: 'memory_error',
            -4: 'unknown',
        }
        
        if exit_code in crash_exit_codes:
            content = ""
            if os.path.exists(error_log_path):
                try:
                    with open(error_log_path, 'r', encoding='utf-8', errors='ignore') as f:
                        content = f.read()
                except:
                    pass
            return self._create_crash_info(crash_exit_codes[exit_code], content)
        
        return False, None
    
    def _create_crash_info(self, crash_type, content):
        trace = self._extract_stack_trace(content)
        crash_trace = tuple([crash_type] + list(trace))
        
        is_new = crash_trace not in self.known_crashes
        
        if is_new:
            self.known_crashes.add(crash_trace)
        
        self.crash_counts[crash_type] += 1
        
        crash_info = {
            'time': datetime.now().isoformat(),
            'type': crash_type,
            'trace': crash_trace,
            'content': content[:2000] if content else '',
            'is_new': is_new,
            'reward': self.crash_rewards.get(crash_type, 10),
            'count': self.crash_counts[crash_type]
        }
        
        self.crash_logs.append(crash_info)
        
        return True, crash_info
    
    def _extract_stack_trace(self, content):
        trace = []
        for line in content.splitlines():
            m = re.match(r'#\d\s+Object ".*?", at .*?, in (.*\(.*\))', line)
            if m:
                trace.append(m.group(1))
        return trace
    
    def get_crash_count(self):
        return len(self.crash_logs)
    
    def get_unique_crashes(self):
        return list(self.known_crashes)
    
    def get_crash_stats(self):
        return dict(self.crash_counts)


class MockCrashDetector:
    """模拟的崩溃检测器"""
    
    def __init__(self):
        self.known_crashes = set()
        self.crash_logs = []
        self.crash_counts = defaultdict(int)
        
        self.crash_rewards = {
            'negative_size': 10,
            'infinite_velocity': 15,
            'empty_plugin': 8,
            'duplicate_model': 12,
            'invalid_clip': 10,
            'bounding_overflow': 18
        }
        
        self.crash_patterns = {
            'negative_size': r'<size>-',
            'infinite_velocity': r'infinite_velocity|inf.*linear|nan.*angular',
            'empty_plugin': r'<plugin filename=""|<plugin\s*/>',
            'duplicate_model': r'<model name="duplicate_model"',
            'invalid_clip': r'<near>10\.0</near>.*<far>5\.0</far>',
            'bounding_overflow': r'<radius>1e\+?20'
        }
    
    def check_crash(self, sdf_content):
        for crash_name, pattern in self.crash_patterns.items():
            if re.search(pattern, sdf_content):
                crash_trace = tuple([crash_name])
                is_new = crash_trace not in self.known_crashes
                
                if is_new:
                    self.known_crashes.add(crash_trace)
                
                self.crash_counts[crash_name] += 1
                
                crash_info = {
                    'time': datetime.now().isoformat(),
                    'type': crash_name,
                    'trace': crash_trace,
                    'content': sdf_content[:500],
                    'is_new': is_new,
                    'reward': self.crash_rewards.get(crash_name, 10)
                }
                self.crash_logs.append(crash_info)
                return True, crash_info
        
        return False, None
    
    def get_crash_count(self):
        return len(self.crash_logs)
    
    def get_unique_crashes(self):
        return list(self.known_crashes)
    
    def get_crash_stats(self):
        return dict(self.crash_counts)
