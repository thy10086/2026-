#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
Gazebo进程管理器 - 支持Docker版本
支持本地安装和Docker容器运行不同版本
"""

import subprocess
import os
import time
import signal
import re
import threading


GAZEBO_VERSIONS = {
    'classic': {
        '11': {
            'name': 'Gazebo 11 (Classic)',
            'install_cmd': 'sudo apt install gazebo11 -y',
            'check_cmd': 'dpkg -l | grep gazebo11',
            'binary': 'gazebo',
            'setup': 'source /usr/share/gazebo/setup.bash',
            'docker_image': 'osrf/gazebo:11'
        },
        '9': {
            'name': 'Gazebo 9 (Classic)',
            'install_cmd': 'sudo apt install gazebo9 -y',
            'check_cmd': 'dpkg -l | grep gazebo9',
            'binary': 'gazebo',
            'setup': 'source /usr/share/gazebo/setup.bash',
            'docker_image': 'osrf/gazebo:9'
        },
        '7': {
            'name': 'Gazebo 7 (Classic - EOL)',
            'install_cmd': 'sudo apt install gazebo7 -y',
            'check_cmd': 'dpkg -l | grep gazebo7',
            'binary': 'gazebo',
            'setup': 'source /usr/share/gazebo/setup.bash',
            'docker_image': 'osrf/gazebo:7'
        },
        '8': {
            'name': 'Gazebo 8 (Classic - EOL)',
            'install_cmd': 'sudo apt install gazebo8 -y',
            'check_cmd': 'dpkg -l | grep gazebo8',
            'binary': 'gazebo',
            'setup': 'source /usr/share/gazebo/setup.bash',
            'docker_image': 'osrf/gazebo:8'
        }
    },
    'ignition': {
        'fortress': {
            'name': 'Ignition Gazebo Fortress',
            'install_cmd': 'sudo apt install ignition-fortress -y',
            'check_cmd': 'dpkg -l | grep ignition-fortress',
            'binary': 'ign gaze',
            'setup': 'source /usr/share/ignition/ignition-fortress/setup.bash',
            'docker_image': 'ignitionrobotics/ignition:fortress'
        }
    }
}

KNOWN_VULNERABLE_VERSIONS = ['7', '8', '9']

CRASH_SIGNALS = {
    -11: ('segmentation_fault', 'SIGSEGV'),
    -6: ('assertion_failure', 'SIGABRT'),
    -8: ('floating_point_exception', 'SIGFPE'),
    -7: ('bus_error', 'SIGBUS'),
    -4: ('illegal_instruction', 'SIGILL'),
    -9: ('killed', 'SIGKILL'),
}

CRASH_KEYWORDS = [
    'Segmentation fault',
    'SIGSEGV',
    'Assertion.*failed',
    'core dumped',
    'terminate called',
    'std::bad_alloc',
    'stack overflow',
    'memory corruption',
    'double free',
    'invalid pointer',
    'realloc(): invalid',
    'malloc(): corrupted',
    'free(): invalid',
]

NORMAL_ERROR_KEYWORDS = [
    'Error loading model',
    'Error parsing',
    'Unable to find',
    'Could not find',
    'Failed to load',
    'does not exist',
    'No such file',
    'Permission denied',
]


class GazeboVersionManager:
    """Gazebo版本管理器 - 支持Docker"""
    
    def __init__(self, wsl_distro='Ubuntu-20.04', use_docker=False):
        self.wsl_distro = wsl_distro
        self.use_docker = use_docker
        self.installed_versions = []
        self.current_version = None
        self.docker_images = []
    
    def run_wsl_command(self, cmd, timeout=30):
        """在WSL中运行命令"""
        try:
            result = subprocess.run(
                ['wsl', '-d', self.wsl_distro, '-e', 'bash', '-c', cmd],
                capture_output=True,
                text=True,
                timeout=timeout
            )
            return result.returncode == 0, result.stdout + result.stderr
        except Exception as e:
            return False, str(e)
    
    def check_version_installed(self, version_key):
        """检查指定版本是否已安装"""
        version_info = None
        for family in GAZEBO_VERSIONS.values():
            if version_key in family:
                version_info = family[version_key]
                break
        
        if not version_info:
            return False
        
        success, output = self.run_wsl_command(version_info['check_cmd'])
        return success
    
    def check_docker_image(self, version_key):
        """检查Docker镜像是否存在"""
        version_info = None
        for family in GAZEBO_VERSIONS.values():
            if version_key in family:
                version_info = family[version_key]
                break
        
        if not version_info or 'docker_image' not in version_info:
            return False
        
        image_name = version_info['docker_image']
        success, output = self.run_wsl_command(f"sudo docker images -q {image_name}")
        return success and output.strip()
    
    def pull_docker_image(self, version_key):
        """拉取Docker镜像"""
        version_info = None
        for family in GAZEBO_VERSIONS.values():
            if version_key in family:
                version_info = family[version_key]
                break
        
        if not version_info or 'docker_image' not in version_info:
            return False, "未找到Docker镜像配置"
        
        image_name = version_info['docker_image']
        print(f"正在拉取Docker镜像: {image_name}...")
        success, output = self.run_wsl_command(f"sudo docker pull {image_name}", timeout=600)
        
        if success:
            print(f"镜像拉取成功: {image_name}")
            return True, output
        else:
            return False, output
    
    def get_installed_versions(self):
        """获取所有已安装的版本"""
        installed = []
        for family_name, family in GAZEBO_VERSIONS.items():
            for version_key, version_info in family.items():
                if self.check_version_installed(version_key):
                    installed.append({
                        'key': version_key,
                        'name': version_info['name'],
                        'family': family_name,
                        'type': 'local'
                    })
        self.installed_versions = installed
        return installed
    
    def get_docker_images(self):
        """获取已拉取的Docker镜像"""
        images = []
        for family_name, family in GAZEBO_VERSIONS.items():
            for version_key, version_info in family.items():
                if 'docker_image' in version_info and self.check_docker_image(version_key):
                    images.append({
                        'key': version_key,
                        'name': version_info['name'],
                        'family': family_name,
                        'type': 'docker',
                        'image': version_info['docker_image']
                    })
        self.docker_images = images
        return images
    
    def install_version(self, version_key):
        """安装指定版本"""
        version_info = None
        for family in GAZEBO_VERSIONS.values():
            if version_key in family:
                version_info = family[version_key]
                break
        
        if not version_info:
            return False, f"未找到版本: {version_key}"
        
        print(f"正在安装 {version_info['name']}...")
        success, output = self.run_wsl_command(version_info['install_cmd'], timeout=300)
        
        if success:
            print(f"安装成功: {version_info['name']}")
            return True, output
        else:
            return False, output
    
    def get_version_info(self, version_key):
        """获取版本信息"""
        for family in GAZEBO_VERSIONS.values():
            if version_key in family:
                return family[version_key]
        return None


class DockerGazeboRunner:
    """Docker容器运行Gazebo"""
    
    def __init__(self, version_key='9', wsl_distro='Ubuntu-20.04', verbose=True):
        self.version_key = version_key
        self.wsl_distro = wsl_distro
        self.verbose = verbose
        self.process = None
        self.error_log = "gz.err"
        self.sdf_file = None
        self.container_id = None
        self.gazebo_version = version_key
        self.crash_detected = False
        self.crash_info = None
        self._stop_monitor = False
        
        self.version_manager = GazeboVersionManager(wsl_distro)
        self.version_info = self.version_manager.get_version_info(version_key)
        
    def run_wsl_command(self, cmd, timeout=30):
        """在WSL中运行命令"""
        try:
            result = subprocess.run(
                ['wsl', '-d', self.wsl_distro, '-e', 'bash', '-c', cmd],
                capture_output=True,
                text=True,
                timeout=timeout
            )
            return result.returncode, result.stdout + result.stderr
        except Exception as e:
            return -1, str(e)
    
    def start_gazebo(self, sdf_file):
        """在Docker容器中启动Gazebo"""
        self.sdf_file = sdf_file
        self.crash_detected = False
        self.crash_info = None
        self._stop_monitor = False
        
        if not self.version_info:
            if self.verbose:
                print(f"    [DockerRunner] 错误: 未找到版本 {self.version_key}")
            return None
        
        image_name = self.version_info.get('docker_image')
        if not image_name:
            if self.verbose:
                print(f"    [DockerRunner] 错误: 版本 {self.version_key} 没有Docker镜像")
            return None
        
        if os.path.exists(self.error_log):
            try:
                os.remove(self.error_log)
            except:
                pass
        
        abs_sdf_path = os.path.abspath(sdf_file)
        sdf_dir = os.path.dirname(abs_sdf_path)
        sdf_name = os.path.basename(abs_sdf_path)
        
        if self.verbose:
            print(f"    [DockerRunner] 启动 {self.version_info['name']} (Docker): {sdf_file}")
        
        docker_cmd = f"sudo docker run --rm -d -v {sdf_dir}:/worlds -w /worlds {image_name} gazebo --server /worlds/{sdf_name}"
        
        returncode, output = self.run_wsl_command(docker_cmd, timeout=60)
        
        if returncode == 0 and output.strip():
            self.container_id = output.strip()[:12]
            if self.verbose:
                print(f"    [DockerRunner] 容器ID: {self.container_id}")
            return self.container_id
        else:
            if self.verbose:
                print(f"    [DockerRunner] 启动失败: {output}")
            return None
    
    def check_crash(self):
        """检查Docker容器中的Gazebo是否崩溃"""
        if self.crash_detected:
            return True, self.crash_info
        
        if not self.container_id:
            return False, None
        
        returncode, output = self.run_wsl_command(f"sudo docker ps -a --filter id={self.container_id} --format '{{{{.Status}}}}'")
        
        if 'Exited' in output:
            exit_code_match = re.search(r'Exited \((\d+)\)', output)
            exit_code = int(exit_code_match.group(1)) if exit_code_match else -1
            
            if exit_code != 0:
                _, logs = self.run_wsl_command(f"sudo docker logs {self.container_id}")
                
                is_real_crash, crash_type = self._analyze_crash_content(logs)
                
                if is_real_crash or exit_code < 0:
                    crash_info = {
                        'type': crash_type if is_real_crash else self._get_signal_crash_type(exit_code),
                        'exit_code': exit_code,
                        'trace': self._extract_trace(logs),
                        'content': logs[:2000],
                        'gazebo_version': self.gazebo_version,
                        'container_id': self.container_id
                    }
                    self.crash_detected = True
                    self.crash_info = crash_info
                    return True, crash_info
            
            return False, None
        
        return False, None
    
    def _get_signal_crash_type(self, exit_code):
        """根据退出码获取崩溃类型"""
        if exit_code < 0:
            signal_num = -exit_code
            crash_type, _ = CRASH_SIGNALS.get(exit_code, ('unknown', f'signal {signal_num}'))
            return crash_type
        return 'unknown'
    
    def _analyze_crash_content(self, content):
        """分析日志内容判断是否真正崩溃"""
        content_lower = content.lower()
        
        for keyword in NORMAL_ERROR_KEYWORDS:
            if keyword.lower() in content_lower:
                for crash_keyword in CRASH_KEYWORDS:
                    if crash_keyword.lower() in content_lower:
                        return True, self._determine_crash_type(content)
                return False, None
        
        for crash_keyword in CRASH_KEYWORDS:
            if re.search(crash_keyword, content, re.IGNORECASE):
                return True, self._determine_crash_type(content)
        
        return False, None
    
    def _determine_crash_type(self, content):
        """确定崩溃类型"""
        content_lower = content.lower()
        
        if 'segmentation fault' in content_lower or 'sigsegv' in content_lower:
            return 'segmentation_fault'
        elif 'assertion' in content_lower and 'failed' in content_lower:
            return 'assertion_failure'
        elif 'terminate called' in content_lower:
            return 'unhandled_exception'
        elif 'std::bad_alloc' in content_lower or 'memory' in content_lower:
            return 'memory_error'
        elif 'stack overflow' in content_lower:
            return 'stack_overflow'
        elif 'floating point' in content_lower or 'sigfpe' in content_lower:
            return 'floating_point_exception'
        elif 'bus error' in content_lower or 'sigbus' in content_lower:
            return 'bus_error'
        elif 'core dumped' in content_lower:
            return 'core_dump'
        else:
            return 'unknown_crash'
    
    def _extract_trace(self, content):
        """提取堆栈跟踪"""
        trace = []
        trace_patterns = [
            r'#\d+\s+.*?in\s+(.*?\(.*?\))',
            r'at\s+(.*?\(.*?\))',
            r'(\w+::\w+\(.*?\))',
        ]
        
        for line in content.splitlines():
            for pattern in trace_patterns:
                m = re.search(pattern, line)
                if m:
                    trace.append(m.group(1))
                    break
        
        return tuple(trace[:10])
    
    def stop_gazebo(self):
        """停止Docker容器"""
        self._stop_monitor = True
        
        if self.container_id:
            if self.verbose:
                print(f"    [DockerRunner] 停止容器 {self.container_id}...")
            self.run_wsl_command(f"sudo docker stop {self.container_id}", timeout=10)
            self.container_id = None
    
    def is_running(self):
        """检查容器是否还在运行"""
        if not self.container_id:
            return False
        
        returncode, output = self.run_wsl_command(f"sudo docker ps --filter id={self.container_id} -q")
        return bool(output.strip())
    
    def set_version(self, version_key):
        """设置版本"""
        self.version_key = version_key
        self.gazebo_version = version_key
        self.version_info = self.version_manager.get_version_info(version_key)


class GazeboRunner:
    """真实运行Gazebo的进程管理器 - 本地安装版本"""
    
    def __init__(self, gazebo_path="gazebo", timeout=30, verbose=True, headless=True,
                 wsl_distro='Ubuntu-20.04', gazebo_version=None):
        self.gazebo_path = gazebo_path
        self.timeout = timeout
        self.verbose = verbose
        self.headless = headless
        self.wsl_distro = wsl_distro
        self.gazebo_version = gazebo_version
        self.process = None
        self.error_log = "gz.err"
        self.sdf_file = None
        self.gazebo_version_info = None
        self.crash_detected = False
        self.crash_info = None
        self._monitor_thread = None
        self._stop_monitor = False
        self.version_manager = GazeboVersionManager(wsl_distro)
        self.start_time = None
        
    def set_version(self, version_key):
        """设置要使用的Gazebo版本"""
        self.gazebo_version = version_key
        self.gazebo_version_info = self.version_manager.get_version_info(version_key)
        
    def _build_command(self, sdf_file):
        """构建启动命令"""
        if self.gazebo_version_info:
            setup = self.gazebo_version_info['setup']
            binary = self.gazebo_version_info['binary']
            
            if 'ign' in binary:
                cmd = f"{setup} 2>/dev/null; {binary} -s {sdf_file}"
            else:
                if self.headless:
                    cmd = f"{setup} 2>/dev/null; {binary} --server {sdf_file}"
                else:
                    cmd = f"{setup} 2>/dev/null; {binary} {sdf_file}"
        else:
            if self.headless:
                cmd = f"source /opt/ros/noetic/setup.bash 2>/dev/null; {self.gazebo_path} --server {sdf_file}"
            else:
                cmd = f"source /opt/ros/noetic/setup.bash 2>/dev/null; {self.gazebo_path} {sdf_file}"
        
        return cmd
        
    def start_gazebo(self, sdf_file):
        self.sdf_file = sdf_file
        self.crash_detected = False
        self.crash_info = None
        self._stop_monitor = False
        self.start_time = time.time()
        
        if os.path.exists(self.error_log):
            try:
                os.remove(self.error_log)
            except:
                pass
        
        version_name = self.gazebo_version_info['name'] if self.gazebo_version_info else "默认版本"
        if self.verbose:
            print(f"    [GazeboRunner] 启动Gazebo ({version_name}): {sdf_file}")
        
        cmd = self._build_command(sdf_file)
        
        try:
            wsl_cmd = ['wsl', '-d', self.wsl_distro, '-e', 'bash', '-c', cmd]
            
            with open(self.error_log, 'w', encoding='utf-8') as err_file:
                self.process = subprocess.Popen(
                    wsl_cmd,
                    stdout=subprocess.PIPE,
                    stderr=err_file
                )
            
            self._monitor_thread = threading.Thread(target=self._monitor_process, daemon=True)
            self._monitor_thread.start()
            
            return self.process.pid
            
        except Exception as e:
            if self.verbose:
                print(f"    [GazeboRunner] 启动Gazebo失败: {e}")
            return None
    
    def _monitor_process(self):
        """后台监控进程崩溃"""
        while not self._stop_monitor and self.process:
            if self.process.poll() is not None:
                break
            time.sleep(0.5)
    
    def check_crash(self):
        """检查Gazebo是否崩溃"""
        if self.crash_detected:
            return True, self.crash_info
        
        if self.process is None:
            return False, None
        
        poll_result = self.process.poll()
        
        if poll_result is None:
            return False, None
        
        if poll_result == 0:
            return False, None
        
        if poll_result < 0:
            crash_type, signal_name = CRASH_SIGNALS.get(poll_result, ('unknown', f'signal {-poll_result}'))
            crash_info = {
                'type': crash_type,
                'signal': signal_name,
                'exit_code': poll_result,
                'trace': (),
                'content': '',
                'gazebo_version': self.gazebo_version
            }
            
            content = self._read_error_log()
            if content:
                crash_info['content'] = content[:2000]
                crash_info['trace'] = self._extract_trace(content)
            
            self.crash_detected = True
            self.crash_info = crash_info
            return True, crash_info
        
        if poll_result > 0:
            content = self._read_error_log()
            
            if not content:
                return False, None
            
            is_real_crash, crash_type = self._analyze_crash_content(content)
            
            if is_real_crash:
                crash_info = {
                    'type': crash_type,
                    'exit_code': poll_result,
                    'trace': self._extract_trace(content),
                    'content': content[:2000],
                    'gazebo_version': self.gazebo_version
                }
                self.crash_detected = True
                self.crash_info = crash_info
                return True, crash_info
            
            return False, None
        
        return False, None
    
    def _read_error_log(self):
        """读取错误日志"""
        if not os.path.exists(self.error_log):
            return ''
        
        try:
            with open(self.error_log, 'r', encoding='utf-8', errors='ignore') as f:
                return f.read()
        except:
            try:
                with open(self.error_log, 'rb') as f:
                    content = f.read()
                return content.decode('utf-8', errors='ignore')
            except:
                return ''
    
    def _analyze_crash_content(self, content):
        """分析日志内容判断是否真正崩溃"""
        content_lower = content.lower()
        
        for keyword in NORMAL_ERROR_KEYWORDS:
            if keyword.lower() in content_lower:
                for crash_keyword in CRASH_KEYWORDS:
                    if crash_keyword.lower() in content_lower:
                        return True, self._determine_crash_type(content)
                return False, None
        
        for crash_keyword in CRASH_KEYWORDS:
            if re.search(crash_keyword, content, re.IGNORECASE):
                return True, self._determine_crash_type(content)
        
        return False, None
    
    def _determine_crash_type(self, content):
        """确定崩溃类型"""
        content_lower = content.lower()
        
        if 'segmentation fault' in content_lower or 'sigsegv' in content_lower:
            return 'segmentation_fault'
        elif 'assertion' in content_lower and 'failed' in content_lower:
            return 'assertion_failure'
        elif 'terminate called' in content_lower:
            return 'unhandled_exception'
        elif 'std::bad_alloc' in content_lower or 'memory' in content_lower:
            return 'memory_error'
        elif 'stack overflow' in content_lower:
            return 'stack_overflow'
        elif 'floating point' in content_lower or 'sigfpe' in content_lower:
            return 'floating_point_exception'
        elif 'bus error' in content_lower or 'sigbus' in content_lower:
            return 'bus_error'
        elif 'core dumped' in content_lower:
            return 'core_dump'
        else:
            return 'unknown_crash'
    
    def _extract_trace(self, content):
        """提取堆栈跟踪"""
        trace = []
        trace_patterns = [
            r'#\d+\s+.*?in\s+(.*?\(.*?\))',
            r'at\s+(.*?\(.*?\))',
            r'(\w+::\w+\(.*?\))',
        ]
        
        for line in content.splitlines():
            for pattern in trace_patterns:
                m = re.search(pattern, line)
                if m:
                    trace.append(m.group(1))
                    break
        
        return tuple(trace[:10])
    
    def stop_gazebo(self):
        self._stop_monitor = True
        
        if self.process is None:
            return
        
        if self.verbose:
            print(f"    [GazeboRunner] 停止Gazebo进程...")
        
        try:
            subprocess.run(
                ['wsl', '-d', self.wsl_distro, '-e', 'bash', '-c', 
                 'pkill -9 gzserver; pkill -9 gzclient; pkill -9 ruby; pkill -9 ign'],
                capture_output=True,
                timeout=5
            )
            
            self.process.terminate()
            try:
                self.process.wait(timeout=3)
            except:
                self.process.kill()
                
        except Exception as e:
            if self.verbose:
                print(f"    [GazeboRunner] 停止进程时出错: {e}")
            try:
                self.process.kill()
            except:
                pass
        
        finally:
            self.process = None
    
    def is_running(self):
        if self.process is None:
            return False
        return self.process.poll() is None


class MockGazeboRunner:
    """模拟的Gazebo运行器"""
    
    def __init__(self, crash_probability=0.3, verbose=True):
        self.crash_probability = crash_probability
        self.verbose = verbose
        self.process = None
        self.gazebo_version = 'mock'
        
    def start_gazebo(self, sdf_file):
        if self.verbose:
            print(f"    [MockRunner] 模拟启动Gazebo: {sdf_file}")
        return 12345
    
    def check_crash(self):
        import random
        if random.random() < self.crash_probability:
            crash_types = ['segmentation_fault', 'assertion_failure', 'null_pointer', 
                          'memory_error', 'stack_overflow', 'bus_error']
            crash_type = random.choice(crash_types)
            return True, {
                'type': crash_type,
                'trace': ('mock_function_1()', 'mock_function_2()'),
                'content': f'Mock crash: {crash_type}',
                'exit_code': -11,
                'is_new': random.random() < 0.3,
                'gazebo_version': 'mock'
            }
        return False, None
    
    def stop_gazebo(self):
        if self.verbose:
            print(f"    [MockRunner] 模拟停止Gazebo")
    
    def is_running(self):
        return False
    
    def set_version(self, version_key):
        self.gazebo_version = version_key
