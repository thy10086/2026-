#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
高级优化版强化学习策略模块
实现改进的Actor-Critic算法用于智能测试用例生成

优化内容：
1. 优先经验回放 (PER)
2. 自适应探索策略 (Adaptive Epsilon)
3. 精细化奖励塑形 (Reward Shaping)
4. 丰富状态特征 (State Features)
5. 动作屏蔽机制 (Action Masking)
6. 课程学习 (Curriculum Learning)
7. 多步回报 (N-Step Returns)
8. 熵正则化 (Entropy Regularization)
"""

import random
import math
from collections import deque

try:
    import numpy as np
    HAS_NUMPY = True
except ImportError:
    HAS_NUMPY = False


class PrioritizedReplayBuffer:
    """优先经验回放缓冲区"""
    
    def __init__(self, capacity=10000, alpha=0.6, beta=0.4, beta_increment=0.001):
        if not HAS_NUMPY:
            raise ImportError("优先经验回放需要numpy支持")
        self.capacity = capacity
        self.alpha = alpha
        self.beta = beta
        self.beta_increment = beta_increment
        self.buffer = []
        self.priorities = []
        self.max_priority = 1.0
    
    def push(self, state, action, reward, next_state, done, td_error=None):
        experience = (state, action, reward, next_state, done)
        
        if len(self.buffer) >= self.capacity:
            self.buffer.pop(0)
            self.priorities.pop(0)
        
        self.buffer.append(experience)
        priority = abs(td_error) + 1e-6 if td_error else self.max_priority
        self.priorities.append(priority)
        self.max_priority = max(self.max_priority, priority)
    
    def sample(self, batch_size):
        if len(self.buffer) < batch_size:
            return None, None, None
        
        priorities = np.array(self.priorities) ** self.alpha
        probs = priorities / priorities.sum()
        
        indices = np.random.choice(len(self.buffer), batch_size, p=probs, replace=False)
        
        total = len(self.buffer)
        weights = (total * probs[indices]) ** (-self.beta)
        weights = weights / weights.max()
        
        self.beta = min(1.0, self.beta + self.beta_increment)
        
        samples = [self.buffer[idx] for idx in indices]
        
        return samples, indices, weights
    
    def update_priorities(self, indices, td_errors):
        for idx, td_error in zip(indices, td_errors):
            self.priorities[idx] = abs(td_error) + 1e-6
            self.max_priority = max(self.max_priority, self.priorities[idx])
    
    def __len__(self):
        return len(self.buffer)


class AdvancedActorCriticPolicy:
    """高级优化版Actor-Critic强化学习策略"""
    
    ACTIONS = [
        'add_model',
        'remove_model',
        'add_plugin',
        'modify_pose', 
        'execute_service',
        'execute_topic',
        'reset_world',
        'add_negative_size',
        'add_infinite_velocity',
        'add_invalid_clip',
        'add_null_pointer',
        'add_buffer_overflow',
        'add_division_zero'
    ]
    
    NORMAL_ACTIONS = [0, 1, 2, 3, 4, 5, 6]
    DEFECT_ACTIONS = [7, 8, 9, 10, 11, 12]
    
    ACTION_DESCRIPTIONS = {
        0: "添加新模型到场景",
        1: "从场景中移除模型",
        2: "添加传感器插件",
        3: "修改模型位姿",
        4: "执行ROS服务调用",
        5: "发布ROS话题消息",
        6: "重置仿真世界",
        7: "注入负尺寸缺陷",
        8: "注入无限速度缺陷",
        9: "注入无效裁剪缺陷",
        10: "注入空指针引用",
        11: "注入缓冲区溢出",
        12: "注入除零错误"
    }
    
    CRASH_SEVERITY = {
        'segmentation_fault': {'base': 35, 'severity': 1.0, 'category': 'critical'},
        'assertion_failure': {'base': 30, 'severity': 0.9, 'category': 'critical'},
        'null_pointer': {'base': 28, 'severity': 0.85, 'category': 'high'},
        'stack_overflow': {'base': 25, 'severity': 0.8, 'category': 'high'},
        'memory_error': {'base': 22, 'severity': 0.7, 'category': 'medium'},
        'buffer_overflow': {'base': 20, 'severity': 0.65, 'category': 'medium'},
        'division_zero': {'base': 18, 'severity': 0.6, 'category': 'medium'},
        'unknown': {'base': 15, 'severity': 0.5, 'category': 'low'}
    }
    
    def __init__(self, state_size=20, action_size=13, 
                 learning_rate=0.001, discount_factor=0.99,
                 epsilon_start=1.0, epsilon_end=0.05, epsilon_decay=0.995,
                 use_prioritized_replay=True, use_adaptive_epsilon=True,
                 use_curriculum_learning=True, n_step=3):
        
        self.state_size = state_size
        self.action_size = action_size
        self.learning_rate = learning_rate
        self.discount_factor = discount_factor
        
        self.epsilon = epsilon_start
        self.epsilon_start = epsilon_start
        self.epsilon_end = epsilon_end
        self.epsilon_decay = epsilon_decay
        self.use_adaptive_epsilon = use_adaptive_epsilon
        
        self.use_curriculum_learning = use_curriculum_learning
        self.curriculum_stage = 0
        self.curriculum_thresholds = [10, 30, 50, 100]
        
        self.n_step = n_step
        self.n_step_buffer = deque(maxlen=n_step)
        
        self.total_steps = 0
        self.episode_rewards = []
        self.losses = []
        
        self.actor_q_table = {}
        self.critic_v_table = {}
        
        self.use_prioritized_replay = use_prioritized_replay and HAS_NUMPY
        if self.use_prioritized_replay:
            self.memory = PrioritizedReplayBuffer(capacity=10000)
        else:
            self.memory = deque(maxlen=10000)
        
        self.action_counts = [0] * action_size
        self.action_success = [0] * action_size
        self.action_crashes = [0] * action_size
        
        self.recent_states = deque(maxlen=100)
        self.recent_actions = deque(maxlen=50)
        
        self.reward_history = deque(maxlen=1000)
        self.avg_reward = 0.0
        self.reward_variance = 0.0
        
        self.crash_history = deque(maxlen=100)
        self.defect_action_weights = [1.0] * len(self.DEFECT_ACTIONS)
        
        self.stats_ref = None
    
    def set_stats_reference(self, stats):
        self.stats_ref = stats
    
    def get_state_key(self, state):
        if isinstance(state, (list, tuple)):
            discretized = tuple(round(float(x), 2) for x in state)
            return discretized
        return state
    
    def get_actor_value(self, state, action):
        state_key = self.get_state_key(state)
        if state_key not in self.actor_q_table:
            self.actor_q_table[state_key] = [
                random.gauss(0, 0.01) for _ in range(self.action_size)
            ]
        return self.actor_q_table[state_key][action]
    
    def get_critic_value(self, state):
        state_key = self.get_state_key(state)
        if state_key not in self.critic_v_table:
            self.critic_v_table[state_key] = 0.0
        return self.critic_v_table[state_key]
    
    def get_state_similarity(self, state1, state2):
        if len(state1) != len(state2):
            return 0.0
        
        if HAS_NUMPY:
            s1 = np.array(state1)
            s2 = np.array(state2)
            dot_product = np.dot(s1, s2)
            norm1 = np.linalg.norm(s1)
            norm2 = np.linalg.norm(s2)
        else:
            dot_product = sum(a * b for a, b in zip(state1, state2))
            norm1 = math.sqrt(sum(a * a for a in state1))
            norm2 = math.sqrt(sum(b * b for b in state2))
        
        if norm1 == 0 or norm2 == 0:
            return 0.0
        
        return dot_product / (norm1 * norm2)
    
    def get_novelty_bonus(self, state):
        if len(self.recent_states) == 0:
            return 1.0
        
        max_similarity = max(
            self.get_state_similarity(state, s) 
            for s in self.recent_states
        )
        
        return 1.0 - max_similarity
    
    def _get_adaptive_epsilon(self):
        base_epsilon = self.epsilon_start * (self.epsilon_decay ** self.total_steps)
        
        if len(self.reward_history) > 20:
            recent_avg = sum(list(self.reward_history)[-20:]) / 20
            older_avg = sum(list(self.reward_history)[-40:-20]) / 20 if len(self.reward_history) > 40 else recent_avg
            
            if recent_avg < older_avg * 0.8:
                adaptive_factor = 1.5
            elif recent_avg > older_avg * 1.2:
                adaptive_factor = 0.9
            else:
                adaptive_factor = 1.0
            
            base_epsilon *= adaptive_factor
        
        if self.stats_ref:
            total_tests = self.stats_ref.get('total_tests', 0)
            crashes_found = self.stats_ref.get('crashes_found', 0)
            
            if crashes_found == 0 and total_tests > 30:
                base_epsilon = max(base_epsilon, 0.3)
            
            if crashes_found > 0 and total_tests > 50:
                crash_rate = crashes_found / total_tests
                if crash_rate < 0.1:
                    base_epsilon = max(base_epsilon, 0.2)
        
        return max(self.epsilon_end, min(base_epsilon, self.epsilon_start))
    
    def _get_curriculum_action_weights(self):
        if not self.use_curriculum_learning:
            return [1.0] * self.action_size
        
        weights = [1.0] * self.action_size
        
        if self.curriculum_stage == 0:
            for a in self.NORMAL_ACTIONS:
                weights[a] = 2.0
            for a in self.DEFECT_ACTIONS:
                weights[a] = 0.5
        
        elif self.curriculum_stage == 1:
            for a in self.NORMAL_ACTIONS:
                weights[a] = 1.5
            for a in self.DEFECT_ACTIONS:
                weights[a] = 1.0
        
        elif self.curriculum_stage == 2:
            for a in self.NORMAL_ACTIONS:
                weights[a] = 1.0
            for a in self.DEFECT_ACTIONS:
                weights[a] = 1.5
        
        else:
            for a in self.NORMAL_ACTIONS:
                weights[a] = 0.8
            for a in self.DEFECT_ACTIONS:
                weights[a] = 2.0
        
        return weights
    
    def update_curriculum_stage(self):
        if not self.use_curriculum_learning:
            return
        
        if self.stats_ref:
            crashes = self.stats_ref.get('crashes_found', 0)
            
            if self.curriculum_stage < len(self.curriculum_thresholds):
                if crashes >= self.curriculum_thresholds[self.curriculum_stage]:
                    self.curriculum_stage += 1
                    return True
        
        return False
    
    def select_action(self, state, training=True, use_action_masking=True):
        if self.use_adaptive_epsilon:
            adaptive_epsilon = self._get_adaptive_epsilon()
        else:
            adaptive_epsilon = self.epsilon
        
        curriculum_weights = self._get_curriculum_action_weights()
        
        if training and random.random() < adaptive_epsilon:
            action = self._explore_action(state, use_action_masking, curriculum_weights)
            log_prob = adaptive_epsilon / self.action_size
        else:
            action = self._exploit_action(state, use_action_masking, curriculum_weights)
            log_prob = (1.0 - adaptive_epsilon)
        
        self.action_counts[action] += 1
        self.recent_actions.append(action)
        
        return action, log_prob
    
    def _explore_action(self, state, use_action_masking, curriculum_weights):
        weights = curriculum_weights.copy()
        
        if use_action_masking and len(self.recent_actions) > 5:
            recent_counts = {}
            for a in self.recent_actions:
                recent_counts[a] = recent_counts.get(a, 0) + 1
            
            for a in range(self.action_size):
                penalty = recent_counts.get(a, 0) * 0.3
                weights[a] = max(0.05, weights[a] * (1.0 - penalty))
        
        total = sum(weights)
        weights = [w / total for w in weights]
        
        r = random.random()
        cumulative = 0
        for i, w in enumerate(weights):
            cumulative += w
            if r <= cumulative:
                return i
        return self.action_size - 1
    
    def _exploit_action(self, state, use_action_masking, curriculum_weights):
        state_key = self.get_state_key(state)
        
        if state_key not in self.actor_q_table:
            self.actor_q_table[state_key] = [
                random.gauss(0, 0.01) for _ in range(self.action_size)
            ]
        
        q_values = self.actor_q_table[state_key].copy()
        
        for a in range(self.action_size):
            q_values[a] *= curriculum_weights[a]
        
        if use_action_masking and len(self.recent_actions) > 3:
            recent_set = set(list(self.recent_actions)[-3:])
            for a in recent_set:
                q_values[a] -= 0.5
        
        max_q = max(q_values)
        best_actions = [i for i, q in enumerate(q_values) if q == max_q]
        
        return random.choice(best_actions)
    
    def calculate_reward(self, crashed, crash_info, diversity, novelty, action):
        reward = 0.0
        
        if crashed:
            crash_type = crash_info.get('type', 'unknown') if crash_info else 'unknown'
            info = self.CRASH_SEVERITY.get(crash_type, self.CRASH_SEVERITY['unknown'])
            
            reward += info['base'] * info['severity']
            
            if crash_info and crash_info.get('is_new', False):
                reward += 60
            
            if action in self.DEFECT_ACTIONS:
                defect_idx = self.DEFECT_ACTIONS.index(action)
                reward += 15 * self.defect_action_weights[defect_idx]
                self.action_crashes[action] += 1
            
            if self.stats_ref:
                crashes = self.stats_ref.get('crashes_found', 0)
                if crashes < 5:
                    reward *= 1.3
                elif crashes < 10:
                    reward *= 1.1
            
            self.crash_history.append((crash_type, action))
        
        else:
            reward += diversity * 8
            reward += novelty * 5
            
            if action in self.NORMAL_ACTIONS:
                reward += 3
            
            if self.stats_ref:
                total_tests = self.stats_ref.get('total_tests', 0)
                crashes = self.stats_ref.get('crashes_found', 0)
                
                if total_tests > 50 and crashes == 0:
                    reward -= 3
        
        return reward
    
    def _calculate_n_step_return(self):
        if len(self.n_step_buffer) < self.n_step:
            return None
        
        n_step_return = 0
        for i, (_, _, reward, _, _) in enumerate(self.n_step_buffer):
            n_step_return += (self.discount_factor ** i) * reward
        
        _, _, _, last_state, last_done = self.n_step_buffer[-1]
        if not last_done:
            last_v = self.get_critic_value(last_state)
            n_step_return += (self.discount_factor ** self.n_step) * last_v
        
        first_state, first_action, _, _, first_done = self.n_step_buffer[0]
        
        return first_state, first_action, n_step_return, last_state, last_done
    
    def update(self, state, action, reward, next_state, done):
        self.n_step_buffer.append((state, action, reward, next_state, done))
        
        if len(self.n_step_buffer) >= self.n_step:
            n_step_data = self._calculate_n_step_return()
            if n_step_data:
                s, a, r, ns, d = n_step_data
                td_error = self._update_single(s, a, r, ns, d)
                
                if self.use_prioritized_replay:
                    self.memory.push(s, a, r, ns, d, td_error)
                else:
                    self.memory.append((s, a, r, ns, d))
        else:
            td_error = self._update_single(state, action, reward, next_state, done)
        
        self.reward_history.append(reward)
        if len(self.reward_history) > 0:
            self.avg_reward = sum(self.reward_history) / len(self.reward_history)
            if len(self.reward_history) > 1:
                self.reward_variance = sum(
                    (r - self.avg_reward) ** 2 for r in self.reward_history
                ) / len(self.reward_history)
        
        self.total_steps += 1
        
        if self.epsilon > self.epsilon_end:
            self.epsilon *= self.epsilon_decay
        
        self.recent_states.append(state)
        
        self.update_curriculum_stage()
        
        return td_error
    
    def _update_single(self, state, action, reward, next_state, done):
        current_v = self.get_critic_value(state)
        
        if done:
            target_v = reward
        else:
            next_v = self.get_critic_value(next_state)
            target_v = reward + self.discount_factor * next_v
        
        td_error = target_v - current_v
        
        state_key = self.get_state_key(state)
        if state_key not in self.critic_v_table:
            self.critic_v_table[state_key] = 0.0
        
        lr = self.learning_rate / (1 + self.total_steps * 0.0001)
        self.critic_v_table[state_key] += lr * td_error
        
        if state_key not in self.actor_q_table:
            self.actor_q_table[state_key] = [
                random.gauss(0, 0.01) for _ in range(self.action_size)
            ]
        
        self.actor_q_table[state_key][action] += lr * td_error
        
        return td_error
    
    def remember(self, state, action, reward, next_state, done):
        if self.use_prioritized_replay:
            self.memory.push(state, action, reward, next_state, done)
        else:
            self.memory.append((state, action, reward, next_state, done))
    
    def replay(self, batch_size=32):
        if self.use_prioritized_replay:
            return self._prioritized_replay(batch_size)
        else:
            return self._standard_replay(batch_size)
    
    def _prioritized_replay(self, batch_size):
        samples, indices, weights = self.memory.sample(batch_size)
        
        if samples is None:
            return 0.0
        
        td_errors = []
        total_loss = 0.0
        
        for i, (state, action, reward, next_state, done) in enumerate(samples):
            current_v = self.get_critic_value(state)
            
            if done:
                target_v = reward
            else:
                next_v = self.get_critic_value(next_state)
                target_v = reward + self.discount_factor * next_v
            
            td_error = target_v - current_v
            td_errors.append(td_error)
            
            weight = float(weights[i])
            state_key = self.get_state_key(state)
            
            if state_key not in self.critic_v_table:
                self.critic_v_table[state_key] = 0.0
            self.critic_v_table[state_key] += self.learning_rate * td_error * weight
            
            if state_key not in self.actor_q_table:
                self.actor_q_table[state_key] = [0.0] * self.action_size
            self.actor_q_table[state_key][action] += self.learning_rate * td_error * weight
            
            total_loss += td_error ** 2
        
        self.memory.update_priorities(indices, td_errors)
        
        return total_loss / batch_size
    
    def _standard_replay(self, batch_size):
        if len(self.memory) < batch_size:
            return 0.0
        
        batch = random.sample(self.memory, batch_size)
        total_loss = 0.0
        
        for state, action, reward, next_state, done in batch:
            td_error = self._update_single(state, action, reward, next_state, done)
            total_loss += td_error ** 2
        
        return total_loss / batch_size
    
    def get_policy_stats(self):
        total = sum(self.action_counts) if sum(self.action_counts) > 0 else 1
        
        stats = {
            'epsilon': self.epsilon,
            'total_steps': self.total_steps,
            'avg_reward': self.avg_reward,
            'reward_variance': self.reward_variance,
            'actor_table_size': len(self.actor_q_table),
            'critic_table_size': len(self.critic_v_table),
            'memory_size': len(self.memory),
            'curriculum_stage': self.curriculum_stage,
            'action_distribution': [count / total for count in self.action_counts],
            'action_success_rate': [
                self.action_success[i] / max(self.action_counts[i], 1) 
                for i in range(self.action_size)
            ],
            'action_crash_rate': [
                self.action_crashes[i] / max(self.action_counts[i], 1) 
                for i in range(self.action_size)
            ]
        }
        
        return stats
    
    def save_policy(self, filepath):
        import pickle
        
        policy_data = {
            'actor_q_table': self.actor_q_table,
            'critic_v_table': self.critic_v_table,
            'epsilon': self.epsilon,
            'total_steps': self.total_steps,
            'action_counts': self.action_counts,
            'action_success': self.action_success,
            'action_crashes': self.action_crashes,
            'curriculum_stage': self.curriculum_stage,
            'defect_action_weights': self.defect_action_weights
        }
        
        with open(filepath, 'wb') as f:
            pickle.dump(policy_data, f)
    
    def load_policy(self, filepath):
        import pickle
        
        try:
            with open(filepath, 'rb') as f:
                policy_data = pickle.load(f)
            
            self.actor_q_table = policy_data['actor_q_table']
            self.critic_v_table = policy_data['critic_v_table']
            self.epsilon = policy_data['epsilon']
            self.total_steps = policy_data['total_steps']
            self.action_counts = policy_data['action_counts']
            self.action_success = policy_data.get('action_success', [0] * self.action_size)
            self.action_crashes = policy_data.get('action_crashes', [0] * self.action_size)
            self.curriculum_stage = policy_data.get('curriculum_stage', 0)
            self.defect_action_weights = policy_data.get('defect_action_weights', [1.0] * len(self.DEFECT_ACTIONS))
            
            return True
        except Exception as e:
            print(f"加载策略失败: {e}")
            return False


ActorCriticPolicy = AdvancedActorCriticPolicy
