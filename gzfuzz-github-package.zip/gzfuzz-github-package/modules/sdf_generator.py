#!/usr/bin/env python3
# -*- coding: utf-8 -*-

"""
SDF模型生成器模块
生成Gazebo SDF模型和世界文件
"""

import random
import math


class SDFModelGenerator:
    """SDF模型生成器"""
    
    GEOM_TYPES = ['box', 'cylinder', 'sphere', 'capsule', 'plane']
    PLUGIN_TYPES = [
        'AckermannSteering', 'LiftDrag', 'LinearBattery', 'DiffDrive',
        'SkidSteerDrive', 'ImuSensor', 'GpsSensor', 'CameraSensor',
        'RaySensor', 'ContactSensor'
    ]
    JOINT_TYPES = ['revolute', 'prismatic', 'fixed', 'ball', 'universal']
    
    def __init__(self):
        self.model_count = 0
        self.link_count = 0
        self.joint_count = 0
    
    def generate_random_string(self, length=10):
        chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'
        return ''.join(random.choice(chars) for _ in range(length))
    
    def generate_random_number(self, min_val, max_val):
        return random.uniform(min_val, max_val)
    
    def generate_geometry(self, crash_type=None):
        geom_type = random.choice(self.GEOM_TYPES)
        result = []
        
        if geom_type == 'box':
            if crash_type == 'negative_size' and random.random() < 0.3:
                size = f"{-self.generate_random_number(1, 10)} {self.generate_random_number(1, 10)} {self.generate_random_number(1, 10)}"
            else:
                size = f"{self.generate_random_number(0.1, 10)} {self.generate_random_number(0.1, 10)} {self.generate_random_number(0.1, 10)}"
            result = [f'<box><size>{size}</size></box>']
        elif geom_type == 'cylinder':
            radius = self.generate_random_number(0.1, 5)
            if crash_type == 'negative_size' and random.random() < 0.3:
                length = -self.generate_random_number(0.1, 10)
            else:
                length = self.generate_random_number(0.1, 10)
            result = [f'<cylinder><radius>{radius}</radius><length>{length}</length></cylinder>']
        elif geom_type == 'sphere':
            radius = self.generate_random_number(0.1, 5)
            if crash_type == 'bounding_overflow' and random.random() < 0.2:
                radius = 1e20
            result = [f'<sphere><radius>{radius}</radius></sphere>']
        elif geom_type == 'capsule':
            radius = self.generate_random_number(0.1, 3)
            length = self.generate_random_number(0.1, 10)
            result = [f'<capsule><radius>{radius}</radius><length>{length}</length></capsule>']
        elif geom_type == 'plane':
            result = ['<plane><size>100 100</size><normal>0 0 1</normal></plane>']
        
        return ''.join(result)
    
    def generate_material(self, crash_type=None):
        ambient = f"{random.random()} {random.random()} {random.random()} 1"
        diffuse = f"{random.random()} {random.random()} {random.random()} 1"
        
        clip_str = ''
        if crash_type == 'invalid_clip' and random.random() < 0.3:
            clip_str = '<clip><near>10.0</near><far>5.0</far></clip>'
        
        return f'<material><ambient>{ambient}</ambient><diffuse>{diffuse}</diffuse>{clip_str}</material>'
    
    def generate_inertial(self):
        mass = self.generate_random_number(0.1, 100)
        return f'<inertial><mass>{mass}</mass></inertial>'
    
    def generate_link(self, crash_type=None):
        self.link_count += 1
        link_name = f'link_{self.link_count}'
        
        collision = f'<collision name="collision_{self.link_count}"><geometry>{self.generate_geometry(crash_type)}</geometry></collision>'
        visual = f'<visual name="visual_{self.link_count}"><geometry>{self.generate_geometry(crash_type)}</geometry>{self.generate_material(crash_type)}</visual>'
        inertial = self.generate_inertial()
        
        velocity_str = ''
        if crash_type == 'infinite_velocity' and random.random() < 0.2:
            velocity_str = '<velocity><linear>inf 0 0</linear><angular>0 0 nan</angular></velocity>'
        
        return f'<link name="{link_name}">{collision}{visual}{inertial}{velocity_str}</link>'
    
    def generate_plugin(self, crash_type=None):
        plugin_type = random.choice(self.PLUGIN_TYPES)
        filename = f'lib{plugin_type}.so'
        plugin_name = self.generate_random_string(10)
        
        if crash_type == 'empty_plugin' and random.random() < 0.25:
            return f'<plugin filename="" name="{plugin_name}"/>'
        
        params = []
        for i in range(random.randint(0, 5)):
            param_name = f'param_{i}'
            param_value = self.generate_random_string(random.randint(5, 20))
            params.append(f'<{param_name}>{param_value}</{param_name}>')
        
        return f'<plugin filename="{filename}" name="{plugin_name}">{"".join(params)}</plugin>'
    
    def generate_joint(self, parent_link, child_link):
        self.joint_count += 1
        joint_type = random.choice(self.JOINT_TYPES)
        joint_name = f'joint_{self.joint_count}'
        
        axis = f'{random.random()} {random.random()} {random.random()}'
        limit_low = self.generate_random_number(-10, 0)
        limit_high = self.generate_random_number(0, 10)
        
        return f'<joint name="{joint_name}" type="{joint_type}"><parent>{parent_link}</parent><child>{child_link}</child><axis><xyz>{axis}</xyz><limit><lower>{limit_low}</lower><upper>{limit_high}</upper></limit></axis></joint>'
    
    def generate_model(self, crash_type=None, duplicate_model=False):
        self.model_count += 1
        if duplicate_model:
            model_name = 'duplicate_model'
        else:
            model_name = f'model_{self.model_count}'
        
        is_static = random.choice([True, False])
        self_collide = random.choice([True, False])
        
        num_links = random.randint(1, 5)
        links = []
        link_names = []
        
        for i in range(num_links):
            link = self.generate_link(crash_type)
            links.append(link)
            link_names.append(f'link_{self.link_count - num_links + i + 1}')
        
        joints = []
        if num_links > 1:
            for i in range(num_links - 1):
                joint = self.generate_joint(link_names[i], link_names[i + 1])
                joints.append(joint)
        
        plugins = []
        for i in range(random.randint(0, 3)):
            plugin = self.generate_plugin(crash_type)
            plugins.append(plugin)
        
        pose = f'{self.generate_random_number(-50, 50)} {self.generate_random_number(-50, 50)} {self.generate_random_number(-10, 50)} 0 0 0'
        
        return f'<model name="{model_name}" static="{str(is_static).lower()}" self_collide="{str(self_collide).lower()}">{"".join(links)}{"".join(joints)}{"".join(plugins)}<pose>{pose}</pose></model>'
    
    def generate_world(self, world_name='default', num_models=3, add_crash_trigger=False):
        crash_type = None
        duplicate_model = False
        
        if add_crash_trigger:
            crash_types = ['negative_size', 'infinite_velocity', 'empty_plugin', 
                          'invalid_clip', 'bounding_overflow']
            crash_type = random.choice(crash_types)
            duplicate_model = random.random() < 0.2
        
        ground = '''<model name="ground" static="true"><link name="ground_link"><collision name="ground_collision"><geometry><plane><size>100 100</size><normal>0 0 1</normal></plane></geometry></collision><visual name="ground_visual"><geometry><plane><size>100 100</size><normal>0 0 1</normal></plane></geometry></visual></link></model>'''
        
        models = [ground]
        for i in range(num_models):
            model_crash = crash_type if i == 0 else None
            model = self.generate_model(model_crash, duplicate_model and i == 1)
            models.append(model)
        
        return f'<sdf version="1.11"><world name="{world_name}">{"".join(models)}</world></sdf>'
    
    def generate_sdf_string(self, world_name='default', num_models=3, add_crash_trigger=False):
        return self.generate_world(world_name, num_models, add_crash_trigger)
